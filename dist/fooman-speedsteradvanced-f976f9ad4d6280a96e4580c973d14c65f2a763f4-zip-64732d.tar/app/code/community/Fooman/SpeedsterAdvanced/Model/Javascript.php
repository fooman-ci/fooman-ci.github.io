<?php

/*
 * @package Minify
 * @author Stephen Clay <steve@mrclay.org>
 */

/*
 *
 * @author     Kristof Ringleff
 * @package    Fooman_SpeedsterAdvanced
 * @copyright  Copyright (c) 2010 Fooman Limited (http://www.fooman.co.nz)
 */

require_once 'minify' . DS . 'Minify' . DS . 'Javascript.php';

class Fooman_SpeedsterAdvanced_Model_Javascript extends Minify_Javascript
{

}