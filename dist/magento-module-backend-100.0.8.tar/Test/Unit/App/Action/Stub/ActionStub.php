<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\Backend\Test\Unit\App\Action\Stub;

class ActionStub extends \Magento\Backend\App\Action
{
    public function execute()
    {
        // Empty method stub for test
    }
}
