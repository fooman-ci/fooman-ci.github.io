<?php

class Fooman_Speedster_Block_Adminhtml_Extensioninfo extends Fooman_Common_Block_Adminhtml_Extensioninfo
{
    protected $_hasSelftest = true;
    protected $_idString = 'speedster';
    protected $_moduleName = 'Fooman_Speedster';
}