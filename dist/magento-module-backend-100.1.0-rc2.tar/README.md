The Backend module contains common infrastructure and assets for other modules to be defined and used in their
administration user interface (UI). It does not contain anything specific to other modules. Among many things it
handles the logic of authenticating and authorizing users.
