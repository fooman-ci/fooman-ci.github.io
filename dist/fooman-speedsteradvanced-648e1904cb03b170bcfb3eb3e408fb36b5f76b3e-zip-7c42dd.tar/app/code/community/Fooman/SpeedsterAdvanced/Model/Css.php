<?php

/*
 * @package Minify
 * @author Stephen Clay <steve@mrclay.org>
 */

/*
 *
 * @author     Kristof Ringleff
 * @package    Fooman_SpeedsterAdvanced
 * @copyright  Copyright (c) 2010 Fooman Limited (http://www.fooman.co.nz)
 */

require_once 'minify' . DS . 'Minify' . DS . 'CSS.php';

class Fooman_SpeedsterAdvanced_Model_Css extends Minify_CSS
{

}
